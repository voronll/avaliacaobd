/* Criação da tabela principal */
CREATE TABLE temporada(
	data_jogo date,
	HomeTeam varchar(100),
	AwayTeam varchar(100),
	FTHG varchar(100),
	FTAG varchar(100),
	FTR varchar(100),
	HTHG varchar(100),
	HTAG varchar(100),
	HTR varchar(100),
	Referee varchar(100),
	HS varchar(100),
	AS_ varchar(100),
	HST varchar(100),
	AST varchar(100),
	HF varchar(100),
	AF varchar(100),
	HC varchar(100),
	AC varchar(100),
	HY varchar(100),
	AY varchar(100),
	HR varchar(100),
	AR varchar(100)
);

/* 1) Import do arquivo .CSV*/
COPY temporada FROM 'season.csv' DELIMITER ',' CSV HEADER NULL 'N/A';

SELECT * FROM temporada --Seleção de toda a tabela para checagem dos elementos


/* 2) A partir dessa query, pode se afirmar que os 5 times que mais fizeram mais gols foram:
1- Man City com 6 gols
2- Liverpool com 5 gols
3- Tottenham com 5 gols
4- Chelsea com 4 gols
5- Burnley com 4 gols
*/
SELECT data_jogo, hometeam AS time_casa, fthg AS gols FROM temporada
ORDER BY fthg DESC
LIMIT 7 -- Foi limitado para 7 rows pois Man City repetia muitas vezes


/* 3) A partir dessa query, pode se afirmar que 18 juízes participaram da temporada */
SELECT DISTINCT referee AS juizes FROM temporada


/* 4) Com essa query, podemos afirmar que os 5 times que mais cometeram faltas fora de casa foram:
1- Bournemouth
2- West Ham
3- Man United
4- Everton
5- Southampton
*/
SELECT DISTINCT awayteam AS time_fora, data_jogo, af AS faltas FROM temporada
ORDER BY af DESC
LIMIT 5